// Bamu Tracker - Authentication Handler (Company Provisioned Only)
const AUTH_STORAGE_KEY = 'bamu_current_user';
const USERS_STORAGE_KEY = 'bamu_company_users';

function initializeCompanyUsers() {
    const existing = localStorage.getItem(USERS_STORAGE_KEY);
    if (!existing) {
        const defaultUsers = [
            {
                email: 'tega@bamutracker.com',
                password: 'password123',
                name: 'Tega',
                role: 'client',
                vehicles: ['Ford Fiesta (T-Tracker #01)']
            }
        ];
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(defaultUsers));
    }
}

function loginUser(email, password) {
    initializeCompanyUsers();
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || '[]');
    
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(user));
        return { success: true, user };
    }
    return { success: false, message: 'Access denied. Accounts can only be created and issued by Bamu company owners.' };
}

function getCurrentUser() {
    const session = localStorage.getItem(AUTH_STORAGE_KEY);
    return session ? JSON.parse(session) : null;
}

function logoutUser() {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    window.location.href = 'index.html';
}

window.BamuAuth = { loginUser, getCurrentUser, logoutUser, initializeCompanyUsers };
